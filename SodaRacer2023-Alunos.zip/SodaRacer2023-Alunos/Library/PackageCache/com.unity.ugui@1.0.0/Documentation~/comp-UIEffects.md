# UI Effect Components

The effects components allow adding simple effects to Text and Image graphics, such as shadow and outline.

* [Shadow](script-Shadow.md)
* [Outline](script-Outline.md)
* [Position as UV1](script-PositionAsUV1.md)
